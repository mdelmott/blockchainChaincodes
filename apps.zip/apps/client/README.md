CLIENT APPLICATION

To build the project, you just need to run these commands :  
``npm install``

``gulp build``

Then you can access it at http://localhost:8000