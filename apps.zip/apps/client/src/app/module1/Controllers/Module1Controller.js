module.exports = function($scope,
                          $http,
                          service2Serv){
    /*$scope.user = "Martin";

    $scope.today = function() {
        $scope.dt = new Date();
    };
    $scope.today();

    $scope.clear = function() {
        $scope.dt = null;
    };

    $scope.options = {
        customClass: getDayClass,
        minDate: new Date(),
        showWeeks: true
    };

    // Disable weekend selection
    function disabled(data) {
        var date = data.date,
            mode = data.mode;
        return mode === 'day' && (date.getDay() === 0 || date.getDay() === 6);
    }

    $scope.toggleMin = function() {
        $scope.options.minDate = $scope.options.minDate ? null : new Date();
    };

    $scope.toggleMin();

    $scope.setDate = function(year, month, day) {
        $scope.dt = new Date(year, month, day);
    };

    var tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    var afterTomorrow = new Date(tomorrow);
    afterTomorrow.setDate(tomorrow.getDate() + 1);
    $scope.events = [
        {
            date: tomorrow,
            status: 'full'
        },
        {
            date: afterTomorrow,
            status: 'partially'
        }
    ];

    function getDayClass(data) {
        var date = data.date,
            mode = data.mode;
        if (mode === 'day') {
            var dayToCheck = new Date(date).setHours(0,0,0,0);

            for (var i = 0; i < $scope.events.length; i++) {
                var currentDay = new Date($scope.events[i].date).setHours(0,0,0,0);

                if (dayToCheck === currentDay) {
                    return $scope.events[i].status;
                }
            }
        }

        return '';
    }*/

    $scope.deployObj = {
        peerUrl : "https://8df5c155d43f45a3b8f8dd88398d116a-vp0.us.blockchain.ibm.com:444",
        chaincodePath : "",
        chaincodeType : "1",
        function : "",
        args : [""]
    };

    $scope.queryObj = {
        function : "",
        args: [""]
    };

    $scope.invokeObj = {
        function : "",
        args : [""]
    };

    $scope.deploy = function(){
        $http.post("http://localhost:3000/deploy", $scope.deployObj)
            .then(function successCallback(response){
                console.log(response);
            }, function errorCallback(error) {
                console.log(error);
            });
    };

    $scope.query = function(){
        $http.post("http://localhost:3000/query", $scope.queryObj)
            .then(function successCallback(response){
                console.log(response);
            }, function errorCallback(error) {
                console.log(error);
            });
    };

    $scope.invoke = function(){
        $http.put("http://localhost:3000/invoke", $scope.invokeObj)
            .then(function successCallback(response){
                console.log(response);
            }, function errorCallback(error) {
                console.log(error);
            });
    };

    $scope.helloWorld = function(){
        return "Hello World!!";
    };
};